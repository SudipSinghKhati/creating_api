

const books = [
    {
        id: 1,
        title : 'JS Fundametnal',
        author : 'Vesh Raj'
    },
    {
        id: 2,
        title : 'War and Peace',
        author : 'Leo Tostoy'
    }, 
    {
        id: 3,
        title : 'Three mistakes of my life',
        author : 'Chetan Bhagat'
    }
];

module.exports = books;